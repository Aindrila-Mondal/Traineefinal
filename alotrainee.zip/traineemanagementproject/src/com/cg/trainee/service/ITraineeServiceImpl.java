package com.cg.trainee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.exceptions.TraineeException;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.dao.ITraineeDao;
@Service
@Transactional
public class ITraineeServiceImpl implements ITraineeService {

	@Autowired
	ITraineeDao dao;
	
	
	
	
	public ITraineeDao getDao() {
		return dao;
	}

	public void setDao(ITraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public TraineeBean addTrainee(TraineeBean trainee) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.addTrainee(trainee);
	}

	@Override
	public List<TraineeBean> getAllTraineeDetails()  {
		// TODO Auto-generated method stub
		return dao.getAllTraineeDetails();
	}

	@Override
	public TraineeBean getaTraineeDetails(int traineeId){
		// TODO Auto-generated method stub
		return dao.getaTraineeDetails(traineeId);
	}

	@Override
	public boolean deleteTrainee(int traineeId) {
	 return dao.deleteTrainee(traineeId);
	}

	@Override
	public TraineeBean updatingTrainee(int traineeId, TraineeBean Trainee) {
		// TODO Auto-generated method stub
		return dao.updatingTrainee(traineeId, Trainee);
	}

	

}
